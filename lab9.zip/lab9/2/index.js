const express = require('express');
const path = require('path');
const app = express();
const port = 3000;

// เพิ่มใช้งานไฟล์
const conn = require('./dbconn.js');
const { Script } = require('vm');

// static resourse
app.use(express.static('public'));
// Set EJS as templating engine

// static resourse & template engine

app.get('/form', function (req, res) {
    res.sendFile(path.join(__dirname, "/public/form.html"));
});

app.get('/process_get', function (req, res) {
    let formdata = {
        username: req.query.username,
        password: req.query.passpword,
    };
    console.log(formdata);  
    //
    let sql = `select * from users where username = "${formdata.username}" and passpword = "${formdata.password}"
    or email = "${formdata.username}" and passpword = "${formdata.password}"`;
    let sql2 = `select * from users where username = "${formdata.username}" or email = "${formdata.username}"`;
    console.log(sql);
    conn.query(sql2, function (err, result) {
        if (err) throw err;
        if (result.length > 0){
            conn.query(sql, function (err, result) {
                if (err) throw err;
                if (result.length > 0){
                    res.send(`<script>alert("เข้าสู่ระบบสำเร็จ"); window.location.href = "/form";</script>`);
                } else {
                    res.send(`<script>alert("รหัสผ่านไม่ถูกต้อง"); window.location.href = "/form";</script>`);
                }
            });
        } else {
            res.send(`<script>alert("ไม่พบบัญชีผู้ใช้"); window.location.href = "/form";</script>`);
        }
        console.log(result);
       
    });
})


app.listen(port, () => {
    console.log(`listening to port ${port}`);
}); 

