const express = require('express');
const path = require('path');
const app = express();
const port = 3000;

// เพิ่มใช้งานไฟล์
const conn = require('./dbconn.js');
const { Script } = require('vm');

// static resourse
app.use(express.static('public'));
// Set EJS as templating engine

// static resourse & template engine

app.get('/form', function (req, res) {
    res.sendFile(path.join(__dirname, "/public/form.html"));
});

app.get('/process_get', function (req, res) {
    let formdata = {
        username: req.query.username,
        passpword: req.query.passpword,
        email: req.query.email,
        firstname: req.query.firstname,
        lastname: req.query.lastname,
        age: req.query.age,
        address: req.query.address,
        phone: req.query.phone,
    };
    console.log(formdata);  
    //
    let sql = `INSERT INTO users values
    ("${formdata.username}", "${formdata.passpword}", "${formdata.email}", "${formdata.firstname}", "${formdata.lastname}", ${formdata.age},
    "${formdata.address}", ${formdata.phone})`;
    console.log(sql);
    conn.query(sql, function (err, result) {
        if (err) throw err;
        console.log("a record inserted");
        res.send(`<script>alert("สำเร็จ"); window.location.href = "/form";</script>`);
    });
})


app.listen(port, () => {
    console.log(`listening to port ${port}`);
}); 

