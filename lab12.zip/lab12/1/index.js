const express = require("express");
const session = require("express-session");
const cookieParser = require("cookie-parser");
const path = require("path");
const PORT = 3000;
const app = express();
const sqlite3 = require('sqlite3').verbose();

// Connect to SQLite database
let db = new sqlite3.Database('customers.db', (err) => {    
    if (err) {
        return console.error(err.message);
    }
    console.log('Connected to the SQlite database.');
});

// static resourse & templating engine      
app.use(express.static('public'));
app.set('view engine', "ejs");

// Middleware setup
app.use(
    session({
        secret: "your-secret-key",
        resave: false,
        saveUninitialized: false,
    })
);

app.use(cookieParser());

// Middleware to check if the user is authenticated
const isAuthenticated = (req, res, next) => {
    if (req.session.user) {
        next();
    } else {
        res.redirect("/login");
    }
};

// Routes
app.get("/", (req, res) => {
    let sql = `select * from customers where CustomerId = "1"`
    console.log(sql);
    db.all(sql, (err,row) => {
        if (err) {
            throw err;
        }
        res.render('index', {data : row.at(0)});
        console.log(row);
    });
});

app.post("/show", (req,res) => {
    let data = {
        "customerid" : req.cookies.customerid, 
        "firstname" : req.cookies.firstname,
        "lastname" : req.cookies.lastname,
        "address" : req.cookies.address,
        "email" : req.cookies.email,
        "phone" : req.cookies.phone
    }
    console.log(data);
    res.render('show', data);
})

app.post("/save", express.urlencoded({ extended: true }), (req, res) => {
    console.log(req.body);
    res.cookie("customerid", req.body.customerid);
    res.cookie("firstname", req.body.firstname);
    res.cookie("lastname", req.body.lastname);
    res.cookie("address", req.body.address);
    res.cookie("email", req.body.email);
    res.cookie("phone", req.body.phone);
    res.sendFile(path.join(__dirname, "/public/blank.html"));
})

app.post("/clear", (req,res) => {
    res.clearCookie('customerid', { path: "/" });
    res.clearCookie('firstname', { path: "/" });
    res.clearCookie('lastname', { path: "/" });
    res.clearCookie('address', { path: "/" });
    res.clearCookie('email', { path: "/" });
    res.clearCookie('phone', { path: "/" });
    res.sendFile(path.join(__dirname, "/public/blank.html"));
    // console.log(req.cookies.phone);
});


// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});