const express = require("express");
const session = require("express-session");
const path = require("path");
const sqlite3 = require("sqlite3").verbose();

const PORT = 3000;
const app = express();

// Connect to SQLite database
let db = new sqlite3.Database("customers.db", (err) => {
    if (err) {
        return console.error(err.message);
    }
    console.log("Connected to the SQlite database.");
});

// Static resources & templating engine
app.use(express.static("public"));
app.set("view engine", "ejs");

// Middleware setup
app.use(
    session({
        secret: "your-secret-key",
        resave: false,
        saveUninitialized: false,
    })
);

app.use(express.urlencoded({ extended: true })); // For parsing form data

// Middleware to check if the user is authenticated
const isAuthenticated = (req, res, next) => {
    if (req.session.user) {
        next();
    } else {
        res.redirect("/login");
    }
};

// Routes
app.get("/", (req, res) => {
    let sql = `SELECT * FROM customers WHERE CustomerId = "1"`;
    console.log(sql);
    db.all(sql, (err, row) => {
        if (err) {
            throw err;
        }
        res.render("index", { data: row.at(0) });
        console.log(row);
    });
});

app.post("/show", (req, res) => {
    let data = {
        customerid: req.session.customerid,
        firstname: req.session.firstname,
        lastname: req.session.lastname,
        address: req.session.address,
        email: req.session.email,
        phone: req.session.phone,
    };
    console.log(data);
    res.render("show", data);
});

app.post("/save", (req, res) => {
    console.log(req.body);
    req.session.customerid = req.body.customerid;
    req.session.firstname = req.body.firstname;
    req.session.lastname = req.body.lastname;
    req.session.address = req.body.address;
    req.session.email = req.body.email;
    req.session.phone = req.body.phone;

    res.sendFile(path.join(__dirname, "/public/blank.html"));
});

app.post("/clear", (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.status(500).send("Error clearing session");
        }
        res.sendFile(path.join(__dirname, "/public/blank.html"));
    });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
