const express = require('express');
const cookieParser = require('cookie-parser');
const app = express();
const path = require("path");
const port = 3000;
const sqlite3 = require('sqlite3').verbose();


// Connect to SQLite database
let db = new sqlite3.Database('yam.db', (err) => {    
    if (err) {
        return console.error(err.message);
    }
    console.log('Connected to the SQlite database.');
});

// static resourse & templating engine
app.use(express.static('public'));
// Set EJS as templating engine
app.set('view engine', 'ejs');
app.use(cookieParser());

app.get('/', (req, res) => {
  
  // parameters: req.cookies.cookie_name
  let visits = parseInt(req.cookies.visits) || 0;
  visits++;
  // set your cookie name
  res.cookie('visits', visits, { maxAge: 86400000 }); 
  // Set cookie expiration 1000*60*60*24 (1 day)

  // Clearing the cookie
  // res.clearCookie('visits'); 

  res.send(`You visited this page ${visits} times.`);
  
});

app.listen(port, () => {
    console.log(`Starting node.js at port ${port}`);
  });

  