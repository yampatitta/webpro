const express = require("express");
const session = require("express-session");
const cookieParser = require("cookie-parser");
const path = require("path");
const PORT = 3000;
const app = express();
const sqlite3 = require('sqlite3').verbose();

// Connect to SQLite database
let db = new sqlite3.Database('yam.db', (err) => {    
    if (err) {
        return console.error(err.message);
    }
    console.log('Connected to the SQlite database.');
});

// static resourse & templating engine
app.use(express.static('public'));

// Middleware setup
app.use(
    session({
        secret: "your-secret-key",
        resave: false,
        saveUninitialized: false,
    })
);

app.use(cookieParser());

// Middleware to check if the user is authenticated
const isAuthenticated = (req, res, next) => {
    if (req.session.user) {
        next();
    } else {
        res.redirect("/login");
    }
};

// Routes
app.get("/", (req, res) => {
    res.send(`Sessions and Cookies Example <a href="/login">Click here</a> to log-in.`);
});

app.get("/login", (req, res) => {
    res.sendFile(path.join(__dirname, "/public/login.html"));
});

app.post("/login", express.urlencoded({ extended: true }), (req, res) => {
    let username = req.body.username;
    let password = req.body.password;
    console.log(req.body);
    let sql = `select * from users where username = "${username}" and password = "${password}"`
    console.log(sql);
    db.all(sql, (err,row) =>{
        if (err) {
            res.send("Invalid credentials. Please try again.");
        } 
        if (row.length > 0) {
            req.session.user = username;
            res.cookie("sessionId", req.sessionID);
            res.redirect("/profile");
        } else {
            res.send("Invalid credentials. Please try again.");
        }
        console.log(row);
    });
});

app.get("/profile", isAuthenticated, (req, res) => {
    // Retrieve user data from the session
    const username = req.session.user;
    res.send(`Welcome, ${username} ! <a href="/logout">Logout</a>`);
});

app.get("/logout", (req, res) => {
    // Destroy the session and redirect to the login page
    req.session.destroy(() => {
        res.clearCookie("sessionId");
        res.redirect("/login");
    });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});