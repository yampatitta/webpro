const express = require("express");
const path = require("path");
const port = 3000;
const sqlite3 = require('sqlite3').verbose();

// Creating the Express server
const app = express();

// Connect to SQLite database


// static resourse & templating engine
app.use(express.static('public'));
// Set EJS as templating engine
app.set('view engine', 'ejs');

app.use(express.json())
app.use(express.urlencoded({ extended: true }))

app.get("/show", (req, res) => {
    const endpoint = 'http://10.0.15.21:8000/countries';    
    fetch(endpoint)
        .then(response => response.json())
        .then(coun => {
            console.log(coun);
            res.render('show', { data: coun });            
        })
        .catch(error => {
            console.log(error);
        });     
});


app.listen(port, () => {
  console.log(`Starting node.js at port ${port}`);
});