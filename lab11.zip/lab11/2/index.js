const express = require("express");
const path = require("path");
const port = 3000;
const sqlite3 = require('sqlite3').verbose();

// Creating the Express server
const app = express();

// Connect to SQLite database
let db = new sqlite3.Database('todo.db', (err) => {    
  if (err) {
      return console.error(err.message);
  }
  console.log('Connected to the SQlite database.');
});


// static resourse & templating engine
app.use(express.static('public'));
// Set EJS as templating engine
app.set('view engine', 'ejs');

app.use(express.json())
app.use(express.urlencoded({ extended: true }))

app.get('/get_todo', (req, res) => {
    const query = 'SELECT * FROM todo ';
    db.all(query, (err, rows) => {
        if (err) {
            console.log(err.message);
        }
        console.log(rows);
        res.send(JSON.stringify(rows));        
    });
});
//3
app.get('/add',(req, res) =>{
    res.sendFile(path.join(__dirname,"/public/form.html"))
})

app.get('/add_todo', (req, res) => {
    let formdata = {
        title: req.query.title,
        description: req.query.description,
        deadline: req.query.deadline

        // ...
    };
    console.log(formdata);  
    //
    let sql = `INSERT INTO todo(Title, Description, Deadline, Completed) VALUES 
    ('${formdata.title}', '${formdata.description}', '${formdata.deadline}', 0)`;
    console.log(sql);
    db.run(sql, (err) => {
        if (err) {
            return console.error('Error inserting data:', err.message);
        }
        console.log('Data inserted successful');
        res.redirect("/show");
    });
});

app.get("/show", (req, res) => {
    const endpoint = 'http://localhost:3000/get_todo';    
    fetch(endpoint)
        .then(response => response.json())
        .then(coun => {
            console.log(coun);
            res.render('show', { data: coun });            
        })
        .catch(error => {
            console.log(error);
        });     
});


app.listen(port, () => {
  console.log(`Starting node.js at port ${port}`);
});